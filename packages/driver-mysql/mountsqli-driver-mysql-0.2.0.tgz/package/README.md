# @mountsqli/driver-mysql

MountSQLI MySQL driver (built on `mysql2`). It implements the same `Driver` contract as the SQLite and Postgres drivers, so multi-driver is a **configuration detail**: point `mount({ driver: "mysql", url })` at a MySQL instance and the compiler picks the `mysqlDialect`.

## Install

```bash
pnpm add @mountsqli/driver-mysql mysql2
```

## Use

```ts
import { mount } from "@mountsqli/core";
import "@mountsqli/driver-mysql"; // side-effect: registers the "mysql" driver

const db = mount({
  driver: "mysql",
  url: "mysql://user:pass@localhost:3306/mydb",
  tables: [/* defineTable(...) */],
});

await db.query(users).insert({ email: "a@b.c" }).run();
```

Or from the CLI (auto-detected via `mount.config.js` → `driver: "mysql"`):

```bash
npx mountsqli migrate generate
npx mountsqli dev
```

## How it maps to MySQL

| Concern | Mapping |
| --- | --- |
| Placeholders | compiled `?` pass through unchanged (positional, like SQLite) |
| Identifier quoting | backticks (`` `col` ``) |
| Auto-increment PK | `INTEGER PRIMARY KEY AUTO_INCREMENT` is emitted in DDL |
| `lastId` | taken from `insertId` on the execute result (MySQL has no `RETURNING`) |
| Booleans | stored as `TINYINT(1)`; bound `0`/`1`, decoded back to `boolean` on read |
| Types | `int→INTEGER`, `text→VARCHAR(255)`, `real→DOUBLE`, `bool→TINYINT(1)`, `blob→BLOB`, `json→JSON`, `uuid→CHAR(36)`, `timestamp→TIMESTAMP` |

Because `mysqlDialect.supportsReturning` is `false`, insert plans don't emit `RETURNING`; the driver recovers the new row id from `insertId` instead — so `insert().run()` still returns a correct `lastId`.

## API

| Export | Kind | Purpose |
| --- | --- | --- |
| `MysqlDriver` | class | `Driver` implementation over `mysql2`. |
| `MysqlConfig` | type | `{ url? \| host?, port?, user?, password?, database?, pool? }`. |
| `registerDriver("mysql")` | side-effect | enables `mount({ driver: "mysql" })`; also registered as `"mysql2"`. |

`mysql2` is loaded lazily via `import("mysql2/promise")`, and a `pool` can be injected for tests/serverless (see `test/mysql.test.ts`, which uses a fake pool — no real MySQL required).

## Tests

```bash
pnpm --filter @mountsqli/driver-mysql test   # vitest: $?->? pass-through, AUTO_INCREMENT DDL, lastId, registration
```
